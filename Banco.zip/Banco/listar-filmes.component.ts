import { FilmesService } from './../../../Services/filmes.service';
import { IFilmes } from './../../../Model/IFilmes.module';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-filmes',
  templateUrl: './listar-filmes.component.html',
  styleUrls: ['./listar-filmes.component.css']
})
export class ListarFilmesComponent implements OnInit {


listarFilmes: IFilmes[] = [


]


  constructor(private ServicesFilmes:FilmesService) { }

  ngOnInit(): void {
    this.carregarFilmes();
  }
  carregarFilmes():void{
    this.ServicesFilmes.buscarTodos().subscribe(retorno=>{
      this.listarFilmes = retorno;
    })
  }
}
