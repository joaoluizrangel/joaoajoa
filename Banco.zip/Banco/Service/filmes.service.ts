import { IFilmes } from './../Model/IFilmes.module';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class FilmesService {

  private URL:string = "http://localhost:3000/filmes";
  constructor(private http : HttpClient ) { }


  buscarTodos():Observable<IFilmes[]>{
    return this.http.get<IFilmes[]>(this.URL);
  }

  cadastrar(filmes: IFilmes) :Observable<IFilmes>{
    return this.http.post<IFilmes>(this.URL,filmes);
  }
}
