export interface IFilmes {
  id?: string,
  title: string,
  lancamento: Date,
  preco: number,
}
